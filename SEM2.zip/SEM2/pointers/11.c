#include<stdio.h>
#include<string.h>
void main()
{
    FILE*file;
    int length;
    char str[100];

    file=fopen("10.txt","r");
    fseek(file,0,SEEK_END);

    length=ftell(file);
    rewind(file);

    while(fread(str,length,1,file))
    {
        printf("%s",str);
    }
}