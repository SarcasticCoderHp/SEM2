#include<stdio.h>
void main()
{
    FILE*file;
    char str[300],s;

    if(file=fopen("p6.txt","r"))
    {
        while(s=fgetc(file)!=EOF)
        {
            printf("%c",s);
        }
    }
    fclose(file);
}