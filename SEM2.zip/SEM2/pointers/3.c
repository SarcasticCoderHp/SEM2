#include<stdio.h>
void main()
{
    FILE*file;
    char str[300];

    if(file=fopen("p3.txt","w"))
    {
        fputc('A',file);
                
    }
    
    fclose(file);
}