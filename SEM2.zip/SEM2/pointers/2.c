#include<stdio.h>
void main()
{
    FILE*file;
    char str[300];

    if(file=fopen("p2.txt","w"))
    {
        if(fprintf(file,"January 2023")>0)
        printf("written successfully\n");
    }
    else printf("ERROR!");
    
    fclose(file);
}