#include<stdio.h>
void main()
{
    FILE*file;
    char str[300],s;

    if(file=fopen("p5.txt","r"))
    {
       printf("%s",fgets(str,50,file));
    }
    fclose(file);
}