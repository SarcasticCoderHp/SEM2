#include<stdio.h>
void main()
{
    FILE*file;
    char str[300];

    if(file=fopen("p1.txt","w"))
    {
        if(fputs("December 2022",file)>0)
        printf("written successfully\n");
    }
    else printf("ERROR!");
    
    fclose(file);
}