#include<stdio.h>
void main()
{
    int x=50;
    int*ptrx;
    ptrx=&x;

    printf("address of x:%d\n",ptrx);
    //printf("value of x:%d\n",*ptrx);
}