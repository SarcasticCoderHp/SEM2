#include<stdio.h>
void main()
{
    FILE*file;
    char str[300],s;

    if(file=fopen("p4.txt","r"))
    {
        while(fscanf(file,"%s",str)!=EOF)
        {
            printf("%s\n",str);
        }
    }
    fclose(file);
}