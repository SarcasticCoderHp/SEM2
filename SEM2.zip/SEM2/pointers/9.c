#include<stdio.h>
int main()
{
    FILE*file;
    file=fopen("p8.txt","w");

    fputs("HELLO WORLD",file);
    fseek(file,11,SEEK_SET);
    fputs("HOW ARE YOU?",file);

    //printf("%s",&file);

    fclose(file);

    return 0;
}
