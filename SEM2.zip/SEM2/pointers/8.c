#include<stdio.h>
#include<string.h>
int main()
{
    FILE*file;
    long int length;

    file=fopen("p7.txt","r");
    fseek(file,0,SEEK_END);
    length=ftell(file);
    fclose(file);

    printf("Size of file is %ld bytes",length);

    return 0;
}
