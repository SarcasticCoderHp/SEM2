#include<stdio.h>
#include<string.h>
void main()
{
    FILE*file;
    char str[100];

    file=fopen("p9.txt","w+");

    printf("Enter the data: ");
    gets(str);

    fwrite(str,strlen(str),1,file);

    fclose(file);
}
