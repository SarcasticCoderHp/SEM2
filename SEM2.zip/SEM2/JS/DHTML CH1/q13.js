function myFunction() 
			{
				var x = prompt("What is your Name: " );
				var y = x.bold();
				document.write("<hr>");
				document.write(y); 
				
				
				var len = x.length;
				document.write("Length is " + len);
				
				
				document.write("<hr>");
				var y = x.italics();
				document.write(y); 
				
				document.write("<hr>");
				var y = x.toUpperCase();
				document.write(y); 

				document.write("<hr>");
				var y = x.toLowerCase();
				document.write(y); 

				document.write("<hr>");
				var y = x.substring(0,3);
				document.write(y); 
				document.write("<hr>");


				var y = x.charAt(2);
				document.write("<hr>");
				document.write(y); 
            }