function validate(){
    var age=parseInt(prompt("Enter age"));
    var ans="not eigible";
    if(age>=18){
        ans="eligible";
    }
    document.write("You are <b>"+ans+"</b> for Vote");
}