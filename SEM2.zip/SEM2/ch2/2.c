#include<stdio.h>
int main()
{
    char fileName[20];

    printf("enter the filename:");
    scanf("%s",fileName);

    FILE*file;
    file=fopen(fileName,"r");

    char c;
    c=fgetc(file);

    while(c!=EOF)
    {
        c=fgetc(file);
        printf("%c",c);
    }
    fclose(file);
}