#include<stdio.h>
int main()
{
    char fileName[20];
    printf("enter the filename:");
    scanf("%s",fileName);

    FILE*file;
    file=fopen(fileName,"w");

        for(int i=0;i<100;i++)
        {
            if(i%2!=0)
            {
                fprintf(file,"%d ",i);
            }
        }
        fclose(file);
    }
