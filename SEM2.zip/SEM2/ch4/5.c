#include <stdio.h>
struct Date {
    int day;
    int month;
    int year;
};
struct Date addDays(struct Date date, int days) {
    date.day += days;
    while (date.day > 30) {
        date.day -= 30;
        date.month++;
    }
    while (date.month > 12) {
        date.month -= 12;
        date.year++;
    }
    return date;
}
int main() {
    struct Date date;
    printf("Enter Current Date: ");
    scanf("%d/%d/%d", &date.day, &date.month, &date.year);
    date = addDays(date, 45);
    printf("Date: %d/%d/%d", date.day, date.month, date.year);
    return 0;
}