#include <stdio.h>

union Integer {
  int num;
  char bytes[4];
};

int main() {
  union Integer i;
  printf("Enter an integer number: ");
  scanf("%d", &i.num);
  printf("=============================================================\n");
  printf("Integer Number: %d \n", i.num);
  printf("Byte 1: %02X \n", i.bytes[0]);
  printf("Byte 2: %02X \n", i.bytes[1]);
  printf("Byte 3: %02X \n", i.bytes[2]);
  printf("Byte 4: %02X \n", i.bytes[3]);
  printf("=============================================================\n");

  
}