#include <stdio.h>

struct Player {
  char name[20];
  int runs;
};

int main() {
  struct Player team[15];
  int total_runs = 0;
  for (int i = 0; i < 11; i++) {
    printf("Enter Player Name:");
    scanf("%s", team[i].name);
    printf("Enter Runs Scored:");
    scanf("%d", &team[i].runs);
    total_runs += team[i].runs;
  }
  printf("=============================================================\n");
  printf("Total Runs Scored: %d \n", total_runs);
  printf("=============================================================\n");
}