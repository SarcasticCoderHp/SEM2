#include <stdio.h>

struct Student {
  int roll_no;
  char stud_name[20];
  char class[20];
};

void display(struct Student s);

int main() {
  struct Student s1;
  printf("Enter the student roll number: ");
  scanf("%d", &s1.roll_no);
  printf("Enter the student name: ");
  scanf("%s", s1.stud_name);
  printf("Enter the student class: ");
  scanf("%s", s1.class);
  display(s1);
}

void display(struct Student s) {
  printf("=============================================================\n");
  printf("Student Roll Number: %d\n", s.roll_no);
  printf("Student Name: %s\n", s.stud_name);
  printf("Student Class: %s\n", s.class);
  printf("=============================================================\n");
}