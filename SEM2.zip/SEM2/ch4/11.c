#include <stdio.h>

struct Distance {
  int feet;
  int inches;
};

int main() {
  struct Distance d1, d2, d3;
  printf("Enter the first distance in feet: ");
  scanf("%d", &d1.feet);
  printf("Enter the first distance in inches: ");
  scanf("%d", &d1.inches);
  printf("Enter the second distance in feet: ");
  scanf("%d", &d2.feet);
  printf("Enter the second distance in inches: ");
  scanf("%d", &d2.inches);
  d3.feet = d1.feet + d2.feet;
  d3.inches = d1.inches + d2.inches;

  printf("=============================================================\n");
  printf("First Distance: %d feet %d inches \n", d1.feet, d1.inches);
  printf("Second Distance: %d feet %d inches \n", d2.feet, d2.inches);
  printf("Total Distance: %d feet %d inches \n", d3.feet, d3.inches);
  printf("=============================================================\n");
}