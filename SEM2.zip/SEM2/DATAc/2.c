#include<stdio.h>
struct student
{
    int rollno;
    char name[50];
    float marks;
}s1={1,"abc",65};
