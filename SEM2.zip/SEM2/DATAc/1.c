#include<stdio.h>
struct student
{
    int rollno;
    char name[50];
    float marks;
};
int main()
{
    struct student s1;
    s1.rollno=8;
    s1.name,"abc";
    s1.marks=96.15;
}
