#include<stdio.h>
struct student
{
    int rollno;
    char name[50];
    float marks;
};
int main()
{
    struct student s1;

    printf("enter the roll no");
    scanf("%d",&s1.rollno);

    printf("enter the name");
    scanf("%s",s1.name);

    printf("enter marks");
    scanf("%.2f",&s1.marks);

    printf("Rollno:%d\n",s1.rollno);
    printf("Name:%s\n",s1.name);
    printf("Marks:%.2f\n",s1.marks);
}