#include<stdio.h>
struct student
{
    char name[50];
    int rollno;
    float percentage;
};

void display(struct student s);
int main()
{
         struct student s1;

         printf("enter the name");
         scanf("%s",s1.name);

         printf("enter roll no");
         scanf("%d",&s1.rollno);

         printf("enter percentage");
         scanf("%f",&s1.percentage);

         display(s1);
         return 0;
}
void display(struct student s)
{
    printf("Name:%s\n",s.name);
    printf("Rollno:%d\n",s.rollno);
    printf("Percentage:%f\n",s.percentage);
}