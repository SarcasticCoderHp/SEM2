#include<stdio.h>
#include<string.h>

struct student
{
    int id;
    char name[50];
    float percentage;
};

void function(struct student*record);
int main()
{
      struct student record;
      record.id=1;
      printf("enter student name");
      scanf("%[^\n]s",record.name);
      record.percentage=86.5;
      function(&record);

      return 0;
}

void function(struct student*record)
{
    printf("Id:%d\n",record->id);
    printf("Name:%s\n",record->name);
    printf("Percentage:%f\n",record->percentage);
}