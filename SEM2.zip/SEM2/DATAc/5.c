#include<stdio.h>
#include<string.h>
struct employee
{
     int id;
     char name[50];
     struct date
     {
        int dd;
        int mm;
        int yyyy;
     }doj;
}s1;

int main()
{
    s1.id=101;
    strcpy(s1.name,"Random");

    s1.doj.dd=10;
    s1.doj.mm=03;
    s1.doj.yyyy=2022;

    printf("Emp_id:%d\n",s1.id);
    printf("Emp_name:%s\n",s1.name);
    printf("Date of joining:%d/%d/%d\n",s1.doj.dd,s1.doj.mm,s1.doj.yyyy);
}