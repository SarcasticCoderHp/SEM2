#include<stdio.h>
union unionjob
{
    char name[20];
    float salary;
    int id;
}u1;

struct structjob
{
    char name[20];
    float salary;
    int id;
}s1;

int main()
{
    printf("Size of union:%ld\n",sizeof(u1));
    printf("Size of structure:%ld\n",sizeof(s1));

    return 0;
}
