#include<stdio.h>
#include<string.h>

struct student
{
    int id;
    char name[50];
    float percentage;
};

int main()
{
	int i;
    struct student s[5];
    for(i=0;i<5;i++)
    {
        printf("enter student id");
        scanf("%d",s[i].id);

        printf("enter student name");
        scanf("%s",s[i].name);

        printf("enter student percentage");
        scanf("%f",s[i].percentage);
    }
    for(i=0;i<5;i++)
    {
        printf("Id:%d\n",s[i].id);
        printf("Name:%s\n",s[i].name);
        printf("Percentage:%f\n",s[i].percentage);
    }
    return 0;
}
