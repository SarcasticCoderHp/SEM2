#include<stdio.h>
struct student getdata();
int main()
{   
         struct student s1;
    printf("%s\n",s1.name);
    printf("%d\n",s1.rollno);
    printf("%f\n",s1.percentage);

    return 0;
}

struct student getdata()
{
	char name[50];
	int roll no;
	float percentage;
};

    struct student s;
    
    printf("enter name");
    scanf("%s",s.name);

    printf("enter roll no");
    scanf("%d",&s.rollno);

    printf("enter percentage");
    scanf("%f",&s.percentage);

    return s;
};
