#include<stdio.h>
#include<string.h>
struct books
{
    char title[50];
    char author[50];
    char subject[100];
    int book_id;
};
int main()
{
    struct books book1;
    struct books book2;

    strcpy(book1.title,"C programming");
    strcpy(book1.author,"E Balasamy");
    strcpy(book1.subject,"C Tutorials");
    book1.book_id=645917;

    printf("enter book title");
    scanf("%s",book2.title);

    printf("enter book author");
    scanf("%s",book2.author);

    printf("enter the subject");
    scanf("%s",book2.subject);

    printf("enter book id");
    scanf("%d",&book2.book_id);

    printf("Title:%s\n",book1.title);
    printf("Author:%s\n",book1.author);
    printf("Subject:%s\n",book1.subject);
    printf("Book_id:%d\n",book1.book_id);

    printf("Title:%s\n",book2.title);
    printf("Author:%s\n",book2.author);
    printf("Subject:%s\n",book2.subject);
    printf("Book_id:%d\n",book2.book_id);
}
