#include<stdio.h>
int main()
{
	int a;
	int*p;
	
	printf("enter the value of a: ");
	scanf("%d",&a);
	
	p=&a;
	
	if(*p%6==0)
	{
		printf("It is divisible by 6");
	}
		else
		{printf("It is not diivisible by 6");
	}
	return 0;
}