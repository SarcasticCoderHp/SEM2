
#include<stdio.h>
int main()
{
	int a[50],n,i;
	int*p;

	printf("enter size of array");
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		printf("enter array elements");
		scanf("%d",&a[i]);
    }
    p=&a[0];
    for(i=0;i<n;i++)
    {
    	if(a[i]>*p){
    		p=&a[i];
    	}
    }
    printf("Maximum number=%d\n",*p);
}