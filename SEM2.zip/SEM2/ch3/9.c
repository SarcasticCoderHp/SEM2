#include <stdio.h>
#include <ctype.h>
int isVowel(char *ch) {
    char newCh = tolower(*ch);
    return newCh == 'a' || newCh == 'e' || newCh == 'i' || newCh == 'o' || newCh == 'u';
}
int isDigit(char *ch) {
    return isdigit(*ch);
}
int main() {
    char ch;
    printf("Enter Character: ");
    scanf("%c", &ch);
    char *p = &ch;
    if (isVowel(p)) {
        printf("Character is Vowel");
    } else if (isDigit(p)) {
        printf("Character is Digit");
    } else {
        printf("Character is Consonant");
    }
    return 0;
}