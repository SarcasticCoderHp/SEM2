#include<stdio.h>
int main()
{
	float r1,l1,*r2,*l2,s,c;

	printf("enter radius");
	scanf("%f",&r1);

	printf("enter length");
	scanf("%f",&l1);

	c=3.14*r1*r1;
    s=l1*l1;

	r2=&c;
	l2=&s;

	printf("area of circle=%f\n",*r2);
	printf("area of square=%f\n",*l2);

	return 0;







	}