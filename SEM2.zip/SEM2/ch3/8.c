#include<stdio.h>
int main()
{
	int emp_id;
	char gender[10];
	float salary;
	void*p;
	
	printf("enter emp_id");
	scanf("%d",&emp_id);
	
	printf("enter gender");
	scanf("%s",gender);
	
	printf("enter salary");
	scanf("%f",&salary);
	
	p=&emp_id;
	printf("emp_id=%d\n",*((int*)p));
	
	p=&gender;
	printf("gender=%s\n",*((char*)p));
	
	p=&salary;
	printf("salary=%.2f\n",*((float*)p));
}