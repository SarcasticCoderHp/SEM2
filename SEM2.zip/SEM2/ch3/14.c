#include<stdio.h>  
int main()  
{  
    int a[5],i,*ptr;  
  
    printf("Enter array elements\n");

    for(i = 0; i < 5; i++)
    {  
        scanf("%d", &a[i]);  
    }
    ptr = &a[5-1];  
  
    printf("\narray elements in reverse order:\n");

    for(i = 0; i < 5; i++)
    {  
        printf("%d\n", *ptr--);  
    }
    return 0;  
}  
