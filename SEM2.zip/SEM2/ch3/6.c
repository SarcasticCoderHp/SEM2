#include<stdio.h>
void check(int*);
int main()
{
	int a;
	int*p;
	printf("enter a number");
	scanf("%d",&a);
	check(&a);
	return 0;
}
void check(int*p)
{
	if(*p%2==0)
	{
		printf("Number is even");
	}
	else{printf("number is odd");}
}