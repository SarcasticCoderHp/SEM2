#include<stdio.h>
int main()
{
	int a,b,c;
	int*p;
	
	printf("enter the value of b: ");
	scanf("%d",&b);
	
	printf("enter the value of c: ");
	scanf("%d",&c);
	
	a=(b+c)*(b-c)/(b*c);
	p=&a;
	
	printf("value of a=%d\n",*p);
	
	return 0;
}