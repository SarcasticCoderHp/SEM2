#include<stdio.h>
int main()
{
   int arr[5];
   int i, sum=0;
   int *ptr;

   printf("\nEnter array elements:");
   for(i=0;i<5;i++)
   {
      scanf("%d",&arr[i]);
   }
   ptr = arr;

   for(i=0;i<5;i++) 
   {
      sum = sum + *ptr;
      ptr++;
   }
   printf("\nThe sum is: %d",sum);

   return 0;
}