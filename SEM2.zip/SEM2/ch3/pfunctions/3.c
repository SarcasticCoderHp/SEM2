#include<stdio.h>
void main()
{
    void*ptr=NULL;
    char*cp=NULL;
    float*fp=NULL;

    printf("Size of void pointer=%d\n\n",sizeof(ptr));
    printf("Size of integer pointer=%d\n\n",sizeof(cp));
    printf("Size of float pointer=%d\n\n",sizeof(fp));
}