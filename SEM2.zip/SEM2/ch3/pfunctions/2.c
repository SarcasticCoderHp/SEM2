#include<stdio.h>
const int MAX=3;
int main()
{
    int var[]={10,100,200};
    int i,*ptr;

    i=0;
    ptr=var;

    while(ptr<&var[MAX-1])
    {
        printf("Address of var[%d]=%p\n",i,ptr);
        printf("Value of var[%d]=%d\n",i,*ptr);

        ptr++;
        i++;
    }
    return 0;

}