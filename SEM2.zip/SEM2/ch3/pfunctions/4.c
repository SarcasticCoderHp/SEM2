#include<stdio.h>
void swap(int*p,int*q)
{
    int r;
    r=*p;
    *p=*q;
    *q=r;
}
int main()
{
    int x,y;
    printf("Enter the value of x and y");
    scanf("%d %d",&x,&y);

    swap(&x,&y);

    printf("After swapping value of x=%d and y=%d\n",x,y);

    return 0;


}