#include<stdio.h>
int add(int*a,int*b);
int sub(int*a,int*b);
int mult(int*a,int*b);
int div(int*a,int*b);
int main()
{
    int a,b,sum=0,subt=0,mul=0,divi=0;

    printf("enter two numbers");
    scanf("%d %d",&a,&b);

    sum=add(&a,&b);
    subt=sub(&a,&b);
    mul=mult(&a,&b);
    divi=div(&a,&b);

    printf("Addition is %d\n",sum);
    printf("Subtraction is %d\n",subt);
    printf("Multiplication is %d\n",mul);
    printf("Division is %d\n",divi);
}
int add(int*a,int*b)
{
    return *a+*b;
}
int sub(int*a,int*b)
{
    return *a - *b;
}
int mult(int*a,int*b)
{
    return *a * *b;
}
int div(int*a,int*b)
{
    return *a / *b;

}
