#include<stdio.h>
int main()
{
    int a,b,sum=0;
    int*ptr1;
    int*ptr2;

    printf("enter two numbers");
    scanf("%d %d",&a,&b);

    ptr1=&a;
    ptr2=&b;

    sum=*ptr1+*ptr2;

    printf("Addition is %d\n",sum);

    return 0;
}