#include<stdio.h>
void fact(int,int*);
int main()
{
    int Fact,num;
    printf("Enter a number");
    scanf("%d",&num);

    fact(num,&Fact);
    return 0;
}
void fact(int n,int*f)
{
    int i;
    *f=1;
    for(i=1;i<=n;i++)
    {
    *f= *f * i;
    }
    printf("Factorial is %d",*f);
}