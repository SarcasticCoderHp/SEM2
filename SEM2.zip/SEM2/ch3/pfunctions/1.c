#include<stdio.h>
int main()
{
    int x;
    int*ptrx;
    ptrx=&x;

    printf("enter value of x");
    scanf("%d",&x);

    printf("value of x=%d\n",x);
    printf("address of x=%p\n",ptrx);
}