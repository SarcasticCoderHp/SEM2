#include<stdio.h>
int*max(int*a,int*b)
{
    if(*a>*b)
    return a;
    else
    return b;
}
int main()
{
    int x,y,z,*ptr;
    printf("enter value of x and y");
    scanf("%d %d",&x,&y);

    ptr=max(&x,&y);

    printf("Maximum is %d",*ptr);
    return 0;
}