#include<stdio.h>
int main()
{
    int i;
    int*ptr;
    ptr=&i;

    printf("enter the value: ");
    scanf("%d",&i);
    ptr++;

    printf("Value after increment=%d\n",ptr);
}