#include<stdio.h>
void swap(int*p,int*q)
{
    *p=*p+*q;
    *q=*p-*q;
    *p=*p-*q;

}
int main()
{
    int x,y;
    printf("Enter the value of x and y");
    scanf("%d %d",&x,&y);

    swap(&x,&y);

    printf("After swapping value of x=%d and y=%d\n",x,y);

    return 0;

}